# 8WHIE Cyber Safety Checklist

**8WHIE — Worldwide Hackers Intelligence & Ethics**

A simple browser-based cybersecurity awareness project.

## Features
- 10-point cyber safety checklist
- Responsive on mobile, tablet and desktop
- Progress indicator
- Mark all / Reset controls
- No API
- No login
- No server
- No personal data collection

## Run
Open `index.html` in a modern web browser.

## Purpose
This project is designed for defensive cybersecurity awareness and everyday digital safety.

Created for the 8WHIE community.
